# ManagmentOfITProjects
Group work for a university project
